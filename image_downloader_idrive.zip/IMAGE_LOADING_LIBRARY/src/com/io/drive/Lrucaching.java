package com.io.drive;


import java.util.HashMap;
import java.io.Serializable;


class Node implements Serializable{
	private static final long serialVersionUID = 2784002581388901845L;
	String key;
    String value;
    Node prev;
    Node next;
 
    public Node(String key, String value){
        this.key=key;
        this.value=value;
    }
}
public class Lrucaching implements Serializable {
    private static final long serialVersionUID = 6284949917731821886L;
	Node head;
    Node tail;
    HashMap<String, Node> map = null;
    int cap = 0;
 
    public Lrucaching(int capacity) {
        this.cap = capacity;
        this.map = new HashMap<>();
    }
 
    public String get(String key) {
        if(map.get(key)==null){
            return null;
        }
 
        //move to tail
        Node t = map.get(key);
 
        removeNode(t);
        offerNode(t);
 
        return t.value;
    }
 
    public void put(String key, String value) {
        if(map.containsKey(key)){
            Node t = map.get(key);
            t.value = value;
 
            //move to tail
            removeNode(t);
            offerNode(t);
        }else{
            if(map.size()>=cap){
                //delete head
                map.remove(head.key);
                removeNode(head);
            }
 
            //add to tail
            Node node = new Node(key, value);
            offerNode(node);
            map.put(key, node);
        }
    }
 
    private void removeNode(Node n){
        if(n.prev!=null){
            n.prev.next = n.next;
        }else{
            head = n.next;
        }
 
        if(n.next!=null){
            n.next.prev = n.prev;
        }else{
            tail = n.prev;
        }
    }
 
    private void offerNode(Node n){
        if(tail!=null){
            tail.next = n;
        }
 
        n.prev = tail;
        n.next = null;
        tail = n;
 
        if(head == null){
            head = tail;   
        }
    }
}