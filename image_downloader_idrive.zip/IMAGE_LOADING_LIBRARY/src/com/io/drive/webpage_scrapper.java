package com.io.drive;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Optional;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.v93.network.Network;
import org.openqa.selenium.devtools.v93.network.model.Response;
import org.openqa.selenium.devtools.v93.network.model.Request;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class webpage_scrapper {

	public static ArrayList<String> DigPageForLink(String PageUrl) throws MalformedURLException, Throwable {
		// TODO Auto-generated method stub

        String url =PageUrl;
        // "https://pikwizard.com/";
         ArrayList<String> urlStore= new ArrayList<String>();  
         System.setProperty("webdriver.chrome.driver","C:\\Program Files\\chromedriver\\chromedriver.exe");
         System.setProperty("webdriver.chrome.whitelistedIps", "");
         ChromeDriver driver = new ChromeDriver();
         JavascriptExecutor jse = (JavascriptExecutor)driver;
         DevTools devTools=driver.getDevTools();
         devTools.createSession();
         devTools.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));
         devTools.addListener(Network.requestWillBeSent(),
                 request -> {
                	 Request req= request.getRequest();
                	 
                     System.out.println("URL - " + req.getUrl());
                 });
         devTools.addListener(Network.responseReceived(),
                 response -> {
                     Response res= response.getResponse();
                     urlStore.add(res.getUrl());
                    // System.out.println("URL - " + res.getUrl());
                     System.out.println("Status - " + res.getStatus());
                    // System.out.println("Headers - " + res.getHeaders());
                    // System.out.println("Header text - " + res.getHeadersText());
                 });
         	driver.get(url);
         	
			//jse.executeScript("window.scrollBy(0,document.body.scrollHeight)");
			jse.executeScript("let scrollerID;\r\n"
					+ "let paused = true;\r\n"
					+ "let speed = 2; // 1 - Fast | 2 - Medium | 3 - Slow\r\n"
					+ "let interval = speed * 5;\r\n"
					+ "\r\n"
					+ "function startScroll(){\r\n"
					+ "    let id = setInterval(function() {\r\n"
					+ "        window.scrollBy(0, 2);\r\n"
					+ "        if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight) {\r\n"
					+ "            // Reached end of page\r\n"
					+ "            stopScroll();\r\n"
					+ "        }\r\n"
					+ "    }, interval);\r\n"
					+ "    return id;\r\n"
					+ "}\r\n"
					+ "\r\n"
					+ "function stopScroll() {\r\n"
					+ "    clearInterval(scrollerID);\r\n"
					+ "}\r\n"
					+ "\r\n"
					+ "document.body.addEventListener('keypress', function (event)\r\n"
					+ "{\r\n"
					+ "    if (event.which == 13 || event.keyCode == 13) {\r\n"
					+ "        // It's the 'Enter' key\r\n"
					+ "        if(paused == true) {\r\n"
					+ "            scrollerID = startScroll();\r\n"
					+ "            paused = false;\r\n"
					+ "        }\r\n"
					+ "        else {\r\n"
					+ "            stopScroll();\r\n"
					+ "            paused = true;\r\n"
					+ "        }\r\n"
					+ "    }\r\n"
					+ "}, true);");
			try {
				Thread.sleep(160000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//LruSimpleCache cache=new LruSimpleCache(250);
			return urlStore;
			
	}
}